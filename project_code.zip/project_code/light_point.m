close all;
IM=imread('D:\ѧϰ\NUS\lecture notes - image processing\church_pic\church.png');

figure,imshow(IM);

IM2 = edge(rgb2gray(IM),'canny'); 

figure,imshow(IM2);

% R=2;
% N=4;
% SE = strel('disk',R,N);
%IM3 = imfill(IM2,'holes') ;

%�ҵ�С������
hole_pixels=20;
filled = imfill(IM2, 'holes');
holes = filled & ~IM2;
bigholes  = bwareaopen(holes, hole_pixels); %��С�ڸ�hole_pixels��������Ŀ׶����
smallholes = holes & ~bigholes;
fill_filtered1_img = IM2 | smallholes;
light_points_bi=fill_filtered1_img-IM2;

figure,imshow(light_points_bi);

%dilate ��Ŵ��Բ��
R=1;
N=8;
SE = strel('disk',R,N);
IM3 = imdilate(light_points_bi,SE) ;
figure,imshow(IM3);

% IM_mask=IM3;
% h=[0 0 1 0 0;
%    0 1 0 1 0;
%    1 0 0 0 1;
%    0 1 0 1 0;
%    0 0 1 0 0]/8;
% star_mask=imfilter(IM_mask,h);
% figure,imshow(star_mask);
star_mask=IM3;

%���������ԭͼ��
new_I=IM;
% new_I_R=new_I(:,:,1);new_I_R(logical(IM3))=255;
% new_I_G=new_I(:,:,2);new_I_G(logical(IM3))=255;
% new_I_B=new_I(:,:,3);new_I_B(logical(IM3))=255;

yellow_bool=star_mask>0;

yellowIndex=repmat(yellow_bool,[1 1 3]);   
yellow=double(IM)/255.*yellowIndex;

yellowsaturated=star_mask;
yellow(:,:,1)=yellowsaturated;
yellow(:,:,2)=yellowsaturated;
yellow(:,:,3)=yellowsaturated;

newHsv=double(IM)/255;
newHsv(yellowIndex)=yellow(yellowIndex);

I_yellow=uint8(newHsv*255);

figure,imshow(I_yellow),title('5.5 yellow');


% 
% new_I(:,:,1)=new_I_R;
% new_I(:,:,2)=new_I_G;
% new_I(:,:,3)=new_I_B;
% figure,imshow(new_I);