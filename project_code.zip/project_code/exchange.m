%close all;
clc;
clear;

portion=40;

img1 = imread('222.png');
[m,n,~]=size(img1);

figure;
imshow(img1);

img2 = imread('haha.jpg');
img2 =imresize(img2,[size(img1,1) size(img1,2)]);

img1=double(img1)/255;
img2=double(img2)/255;

figure;
imshow(img2);
r1=img1(:,:,1);
g1=img1(:,:,2);
b1=img1(:,:,3);
r2=img2(:,:,1);
g2=img2(:,:,2);
b2=img2(:,:,3);
%����Ҷ�任
f_fft_r1 = fftshift(fft2(r1));
f_fft_g1 = fftshift(fft2(g1));
f_fft_b1 = fftshift(fft2(b1));
f_fft_r2 = fftshift(fft2(r2));
f_fft_g2 = fftshift(fft2(g2));
f_fft_b2 = fftshift(fft2(b2));
%��ȡ����
f_magnitude_r1 = abs(f_fft_r1);
f_magnitude_g1 = abs(f_fft_g1);
f_magnitude_b1 = abs(f_fft_b1);
f_magnitude_r2 = abs(f_fft_r2);
f_magnitude_g2 = abs(f_fft_g2);
f_magnitude_b2 = abs(f_fft_b2);

%��ȡ��λ
f_phase_r1 = angle(f_fft_r1);     
f_phase_g1 = angle(f_fft_g1);
f_phase_b1 = angle(f_fft_b1);
f_phase_r2 = angle(f_fft_r2);
f_phase_g2 = angle(f_fft_g2);
f_phase_b2 = angle(f_fft_b2);

%��λ���Ƚ���
f_phase_me_r1 = f_magnitude_r1.*(exp(1i.*f_phase_r2));
f_phase_me_g1 = f_magnitude_g1.*(exp(1i.*f_phase_g2));
f_phase_me_b1 = f_magnitude_b1.*(exp(1i.*f_phase_b2));
f_phase_me_r2 = f_magnitude_r2.*(exp(1i.*f_phase_r1.*(f_phase_r1<0)));
f_phase_me_g2 = f_magnitude_g2.*(exp(1i.*f_phase_g1.*(f_phase_g1<0)));
f_phase_me_b2 = f_magnitude_b2.*(exp(1i.*f_phase_b1.*(f_phase_b1<0)));

%����Ҷ���任
f_ifft_r1=real(ifft2(ifftshift(f_phase_me_r1)));
f_ifft_g1=real(ifft2(ifftshift(f_phase_me_g1)));
f_ifft_b1=real(ifft2(ifftshift(f_phase_me_b1)));
f_ifft_r2=real(ifft2(ifftshift(f_phase_me_r2)));
f_ifft_g2=real(ifft2(ifftshift(f_phase_me_g2)));
f_ifft_b2=real(ifft2(ifftshift(f_phase_me_b2)));

out1(:,:,1)=f_ifft_r1;
out1(:,:,2)=f_ifft_g1;
out1(:,:,3)=f_ifft_b1;
out2(:,:,1)=f_ifft_r2;
out2(:,:,2)=f_ifft_g2;
out2(:,:,3)=f_ifft_b2;

imout=zeros(m,n,3);

for i = 1:m
    for j = 1:n 
            imout(i,j,1) = ((img1(i,j,1)*(100 - portion) + out2(i,j,1)*portion))/100;
            imout(i,j,2) = ((img1(i,j,2)*(100 - portion) + out2(i,j,2)*portion))/100;
            imout(i,j,3) = ((img1(i,j,3)*(100 - portion) + out2(i,j,3)*portion))/100;
    end
end
imout=uint8(imout*255);

figure;
imshow(uint8(out1*255));
title('ͼһ��������ͼ����λ�׵ĸ���Ҷ���任');
figure;
imshow(uint8(out2*255));
title('ͼ����������ͼһ��λ�׵ĸ���Ҷ���任');

figure;
imshow(imout);
title('���');
