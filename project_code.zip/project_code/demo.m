clc;
clear all;
close all;

%% 1.read in file
I=imread('beach.jpg');
figure,imshow(I),title('Original image');

I2=I;
%% 2.Gaussian filter
I2=double(I2);
I_g=I2;

hsize=[5 5];%ADJUST HERE!
sigma=0.7;%ADJUST HERE!
h = fspecial('gaussian', hsize, sigma);

I05_R=imfilter(I2(:,:,1),h);
I05_G=imfilter(I2(:,:,2),h);
I05_B=imfilter(I2(:,:,3),h);

I_g(:,:,1)=I05_R;
I_g(:,:,2)=I05_G;
I_g(:,:,3)=I05_B;
I_g=uint8(I_g);
figure,imshow(I_g),title('Gaussian image');

%% 3.dirty filter
I3=dirty_filter( I_g );

figure,imshow(I3),title('dirty filter image');

%% 4.Saturation enhanced(green and blue)

imghsv=I3;
imghsv=rgb2hsv(im2double(imghsv));
%enhance hue from degree 90 to 270 (green and blue)
yellow_bool=(imghsv(:,:,1)>90/360)&(imghsv(:,:,1)<270/360); %ADJUST HERE!
yellowIndex=repmat(yellow_bool,[1 1 3]);   
yellow=imghsv.*yellowIndex;

%Saturate it
moreSaturation=3;
yellowsaturated=yellow(:,:,2)*moreSaturation;
yellow(:,:,2)=yellowsaturated;

%put it back
newHsv=imghsv; 
newHsv(yellowIndex)=yellow(yellowIndex);

newRgb=hsv2rgb(newHsv);
newRgb=uint8(newRgb*255);
figure,imshow(newRgb),title('blue and green saturation enhanced');

%% 5.oil-painting

win_size=3;%ADJUST HERE!
intensityLevel=20; %ADJUST HERE!

I4=oil_painting(newRgb,win_size,intensityLevel);

figure,imshow(I4),title('oil painting image');


%% 6.Add Texture and contour

Input = I4;
dirNum = 8;%��ʾ����dirNum������ľ�����
[m, n, src] = size(Input);
ks = floor(min(m/50, n/50) + 0.5);%������Ҫ��Ϊ�߻����1/30��ʵ���ϲ�����ô��
ks = 5;%�����˴�С��������ͼƬΪ10~13���羰������ͼƬΪ3~6
strokeDepth = 2;%�����ɵ�����ͼ���輸��
 
w1 = 0.57;%��˹�ֲ�Ȩ��
w2 = 0.37;%���ȷֲ�Ȩ��
w3 = 0.06;%������˹�ֲ�Ȩ��
 
Back = rgb2gray(imread('texture1.jpg'));%���뱳��Ǧ��ͼ
backDepth = 1;%��Ǧ�ʱ���ͼpencil.jpg���輸��
renderDepth = 3;%�����ɵ�������Ⱦͼ���輸��
theta=0.1; % ��Եƽ���̶�
portion=15; %���������ı��� (15%)        %ADJUST HERE!

%���������ǻҶ�ͼ�񣬶�����д���
if src == 1
    %gray_out = rgb2gray(Input);
    gray_out=Input;
    gray_out = grayPencilDrawing(gray_out,dirNum, ks, strokeDepth, w1, w2, w3, Back, backDepth, renderDepth,theta,portion);
end
%���������ǲ�ɫͼ�񣬶�����д���
if src == 3
    I5 = mat2gray(Input);
    R = I5(:, :, 1);
    G = I5(:, :, 2);
    B = I5(:, :, 3);
    
    Y = 0.299*R + 0.587*G + 0.114*B;
    U = -0.147*R- 0.289*G + 0.436*B;
    V = 0.615*R - 0.515*G - 0.100*B;
    Y = uint8(Y .* 255);
    Y = grayPencilDrawing(Y,dirNum, ks, strokeDepth, w1, w2, w3,  Back, backDepth, renderDepth,theta,portion);
    %yuv_out = cat(3, Y, U, V);%���յ���ά���
    I5(:,:,1) = Y + 1.14 * V;
    I5(:,:,2) = Y - 0.39 * U - 0.58 * V;
    I5(:,:,3) = Y + 2.03 * U;
end

figure,imshow(I5),title('texture added image');

%% 7.Yellow filter
image = I5;
 image_r=image(:,:,1);
 image_g=image(:,:,2);
 image_b=image(:,:,3);
 image_r1=uint8(double(image_r)*0.5*255 +0.5*double(image_r)*252);
 image_g1=uint8(double(image_g)*0.5*255+0.5*double(image_g)*137);
 image_b1=uint8(double(image_b)*0.5*255+0.5*double(image_b)*60);
 zero = zeros(size(image_r));
 I6=cat(3,image_r1,image_g1,image_b1);

 figure,imshow(I6),title('yellow filter image');
 
%% 8.saturation enhanced(full range)

imghsv=I6;
imghsv=rgb2hsv(im2double(imghsv));

yellow_bool=(imghsv(:,:,1)>0/360)&(imghsv(:,:,1)<360/360); %ADJUST HERE!
yellowIndex=repmat(yellow_bool,[1 1 3]);   
yellow=imghsv.*yellowIndex;

%Saturate it
moreSaturation=1.2;%ADJUST HERE!
yellowsaturated=yellow(:,:,2)*moreSaturation;
yellow(:,:,2)=yellowsaturated;

%put it back
newHsv=imghsv; 
newHsv(yellowIndex)=yellow(yellowIndex);
newHsv(:,:,3)=imghsv(:,:,3).*1.5;

I_yellow=hsv2rgb(newHsv);
I_yellow=uint8(I_yellow*255);

figure,imshow(I_yellow),title('saturation enhanced image(full range)');

%% 9.Ha transform ����λ���Ƚ����󣬵��ף�
ha_portion=20;
I_ha=ha_transform(I_yellow,imread('haha.jpg'),ha_portion);
figure,imshow(I_ha),title('Ha transformed image');

 %% 6.Add fog
 I7=ImageAddfog( I_ha,imread('white.jpg') );
 I7=uint8(I7*255);
 figure,imshow(I7),title('fog added image');
 %% 7 Add blurred fliter
%Gussian size
hsize=[30 30];
sigma=20;
%I8=zeros(m,n,3);
I8=blurred_filter(I7,hsize,sigma);
%figure,imshow(I8),title('blurred image');
 %% 8.final result
 figure,imshow(I8),title('final result image');
 