function [ I8 ] = blurred_filter( I7,hsize,sigma )
I7=double(I7)/255;
I_b=I7;

%Gussian size
% hsize=[40 40];
% sigma=40;

h = fspecial('gaussian', hsize, sigma);

I05_R=imfilter(I7(:,:,1),h);
I05_G=imfilter(I7(:,:,2),h);
I05_B=imfilter(I7(:,:,3),h);

I_b(:,:,1)=I05_R;
I_b(:,:,2)=I05_G;
I_b(:,:,3)=I05_B;
I_b=uint8(I_b*255);
%figure,imshow(I_g),title('Gaussian image');

I8=I7;
I8(:,:,1)=(I8(:,:,1)+I05_R)/2;
I8(:,:,2)=(I8(:,:,2)+I05_G)/2;
I8(:,:,3)=(I8(:,:,3)+I05_B)/2;
I8=uint8(I8*255);
%figure,imshow(I8),title('blurred image');
end

