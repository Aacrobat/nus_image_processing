function [ new_I ] = oil_painting(I,win_size,intensityLevel)
[row,col,~]=size(I);

new_I=uint8(zeros(row,col,3));

pad_image=padarray(I,[(win_size-1)/2 (win_size-1)/2]);

for i=1:row
    for j=1:col
        window=double(pad_image(i:i+win_size-1,j:j+win_size-1,:));
        intensityCount=zeros(1,intensityLevel+1);
        avgR=zeros(1,intensityLevel+1);
        avgG=zeros(1,intensityLevel+1);
        avgB=zeros(1,intensityLevel+1);
        for m=1:win_size
            for n=1:win_size
                curIntensity=floor(sum(window(m,n,:)/3*intensityLevel)/255)+1;
                intensityCount(curIntensity)=intensityCount(curIntensity)+1;
                avgR(curIntensity)=avgR(curIntensity)+window(m,n,1);
                avgG(curIntensity)=avgG(curIntensity)+window(m,n,2);
                avgB(curIntensity)=avgB(curIntensity)+window(m,n,3);
            end
        end
        
        [value, index]=max(intensityCount);
        
        new_I(i,j,1)=uint8(avgR(index)/value);
        new_I(i,j,2)=uint8(avgG(index)/value);
        new_I(i,j,3)=uint8(avgB(index)/value);
    end
end


end

