function [ imout ] = ImageAddfog( ima,imb )
imb=rgb2gray(imb);
[m,n,g] = size(ima);
[a,b,g1] = size(imb);


rect=[1,1,n,m];
imb =imresize(imb,[size(ima,1) size(ima,2)]);

%imb=imresize(imb,m/a);

ima = im2double(ima);
imb = im2double(imb);



for i = 1:m
    for j = 1:n
        if i^2+j^2<m*n/4
            imout1(i,j,:) = ima(i,j,:)*sqrt(i^2+j^2)/sqrt(m*n/4) + imb(i,j,:)*(1 - sqrt(i^2+j^2)/sqrt(m*n/4));
        else
            imout1(i,j,:) = ima(i,j,:);
        end
        
    end
end

for i = 1:m
    for j = 1:n
        if i^2+(n-j)^2<m*n/2
        imout2(i,j,:)=ima(i,j,:)*sqrt(i^2+(n-j)^2)/sqrt(m*n/2)+imb(i,j,:)*(1 - sqrt(i^2+(n-j)^2)/sqrt(m*n/2));
        else
            imout2(i,j,:)=ima(i,j,:);
        end
    end
end

imout=(imout1+imout2)/2;
end