%Read image
I2=imread('D:\ѧϰ\NUS\lecture notes - image processing\�˾�\yellow.png');
%I2=imread('../xlz_small.jpg');

% 2.5 Gaussian filter
I2=double(I2)/255;
I_g=I2;

%Gussian size
hsize=[40 40];
sigma=40;

h = fspecial('gaussian', hsize, sigma);

I05_R=imfilter(I2(:,:,1),h);
I05_G=imfilter(I2(:,:,2),h);
I05_B=imfilter(I2(:,:,3),h);

I_g(:,:,1)=I05_R;
I_g(:,:,2)=I05_G;
I_g(:,:,3)=I05_B;
I_g=uint8(I_g*255);
figure,imshow(I_g),title('Gaussian image');

I_final=I2;
I_final(:,:,1)=(I_final(:,:,1)+I05_R)/2;
I_final(:,:,2)=(I_final(:,:,2)+I05_G)/2;
I_final(:,:,3)=(I_final(:,:,3)+I05_B)/2;
I_final=uint8(I_final*255);
figure,imshow(I_final),title('final image');