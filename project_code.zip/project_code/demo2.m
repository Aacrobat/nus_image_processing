clc;
clear all;
close all;

%% 0.read in file
%I = imread('D:\ѧϰ\NUS\lecture notes - image processing\monkey.png');
%I = imread('..\flower_mid.jpg');
I=imread('D:\ѧϰ\NUS\lecture notes - image processing\church_pic\church.png');
%I = imread('..\firework.jpg');
figure,imshow(I),title('Original image');



% %% 1.�߹⽵��
% I2=uint8(highlight_adjust( I ));
% 
% figure,imshow(I2),title('highlight adjust image');
%%%%%%%%%%%%%
I2=I;
%% 2.5 Gaussian filter
I2=double(I2);
I_g=I2;

hsize=[5 5];
sigma=0.7;
h = fspecial('gaussian', hsize, sigma);

I05_R=imfilter(I2(:,:,1),h);
I05_G=imfilter(I2(:,:,2),h);
I05_B=imfilter(I2(:,:,3),h);

I_g(:,:,1)=I05_R;
I_g(:,:,2)=I05_G;
I_g(:,:,3)=I05_B;
I_g=uint8(I_g);
figure,imshow(I_g),title('Gaussian image');

%% 2.dirty filter
I3=dirty_filter( I_g );

figure,imshow(I3),title('dirty filter image');

%% 2.7 saturation enhanced

imghsv=I3;
%figure,imshow(imghsv),title('Ori');
imghsv=rgb2hsv(im2double(imghsv));

%pick yellow
yellow_bool=(imghsv(:,:,1)>90/360)&(imghsv(:,:,1)<270/360); %blue
%yellow_bool=(imghsv(:,:,1)>0);
%component

%yellow_bool=(imghsv(:,:,2)<0.1)&(imghsv(:,:,3)>0.5);

%figure,imshow(yellow_bool),title('yellow part');

yellowIndex=repmat(yellow_bool,[1 1 3]);   
yellow=imghsv.*yellowIndex;

%Saturate it
moreSaturation=3;
yellowsaturated=yellow(:,:,2)*moreSaturation;
yellow(:,:,2)=yellowsaturated;

%put it back
newHsv=imghsv; 
newHsv(yellowIndex)=yellow(yellowIndex);

newRgb=hsv2rgb(newHsv);
newRgb=uint8(newRgb*255);
figure,imshow(newRgb),title('2.7 90-270');
